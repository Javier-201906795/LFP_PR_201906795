

class FuncionesGenerales():

    def mensajebienvenida(self):
        
        print("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓")
        print("▓▓           PRACTICA 1 LFP           ▓▓")
        print("▓▓   Javier Ricardo Yllescas Barrios  ▓▓")
        print("▓▓   Carne: 201906795                 ▓▓")

        print("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓")

    def holamundo(self):
        print("hola mundo ...")